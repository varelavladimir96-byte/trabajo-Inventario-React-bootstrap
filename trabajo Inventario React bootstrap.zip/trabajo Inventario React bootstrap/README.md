# Inventario de equipos del laboratorio — Grupo 01

Proyecto práctico de React, JavaScript (JSX) y Bootstrap 5 para la asignatura Desarrollo de Entornos Web II.

## Requisitos implementados
- Arreglo de objetos con seis equipos y los campos `id`, `nombre`, `categoria`, `cantidad` y `estado`.
- Componente reutilizable `TarjetaEquipo` que recibe información mediante `props`.
- Generación de tarjetas con `map()` y `key={equipo.id}`.
- Botón Mostrar/Ocultar inventario con `useState` y `onClick`.
- Bootstrap 5: `container`, `row`, `col`, `card`, `badge` y `btn`.
- Diseño adaptable para computadora, tablet y teléfono.
- Resumen visual de tipos de equipo, tipos disponibles y unidades registradas.

## Cómo ejecutar
1. Instalar Node.js si aún no está instalado.
2. Abrir esta carpeta en Visual Studio Code.
3. Abrir una terminal dentro de la carpeta del proyecto.
4. Ejecutar:

   ```bash
   npm install
   npm run dev
   ```

5. Abrir en el navegador la dirección local que muestra Vite, normalmente `http://localhost:5173`.

## Archivos principales
- `src/App.jsx`: datos, resumen y estado para mostrar u ocultar el inventario.
- `src/components/TarjetaEquipo.jsx`: tarjeta reutilizable que presenta cada equipo.
- `src/main.jsx`: punto de entrada e importación de Bootstrap.
- `src/styles.css`: estilos visuales y ajustes responsivos.

## Guía breve para la defensa
**¿Qué es Bootstrap?** Es un framework CSS que facilita crear interfaces con componentes y cuadrículas adaptables. En el proyecto usamos `container`, `row`, `col`, `card`, `badge` y `btn`.

**¿Qué hace App?** Mantiene el arreglo de equipos, calcula el resumen y controla si las tarjetas se muestran.

**¿Qué hace TarjetaEquipo?** Es un componente reutilizable que recibe un objeto `equipo` mediante props y presenta su información.

**¿Qué hace useState?** Guarda el estado de visibilidad del inventario. El evento `onClick` cambia ese estado al pulsar el botón.

**¿Qué hace map()?** Recorre el arreglo y crea una tarjeta por cada equipo. La propiedad `key` usa el `id` único y estable para identificar cada tarjeta.

**¿Cómo es adaptable?** Usa las clases de columnas de Bootstrap (`col-12`, `col-sm-6`, `col-lg-4`) y reglas CSS `@media` para ajustar el diseño a diferentes anchos.

## Entrega
El ZIP de entrega debe incluir los archivos del proyecto, pero no `node_modules`. Ejecutar `npm install` al descomprimirlo para instalar las dependencias.
