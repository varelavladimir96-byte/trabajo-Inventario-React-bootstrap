import React from 'react';
function TarjetaEquipo({ equipo }) {
  const estadoClase = {
    'Disponible': 'status-available',
    'Mantenimiento': 'status-maintenance',
    'Uso limitado': 'status-limited'
  }[equipo.estado] || 'status-limited';

  return (
    <article className="card equipment-card h-100">
      <div className="card-body">
        <div className="equipment-card-top">
          <div className="equipment-icon" aria-hidden="true">{equipo.icono}</div>
          <span className={`badge status-badge ${estadoClase}`}>{equipo.estado}</span>
        </div>
        <span className="equipment-category">{equipo.categoria}</span>
        <h3 className="card-title">{equipo.nombre}</h3>
        <p className="card-text equipment-description">{equipo.descripcion}</p>
        <div className="quantity-row">
          <span>Cantidad disponible</span>
          <strong>{equipo.cantidad} <small>unid.</small></strong>
        </div>
      </div>
      <div className="card-footer">
        <span className="record-dot"></span>
        Código de equipo <strong>EQ-{String(equipo.id).padStart(3, '0')}</strong>
      </div>
    </article>
  );
}

export default TarjetaEquipo;