import React, { useState } from 'react';
import TarjetaEquipo from './components/TarjetaEquipo';
const equipos = [
  {
    id: 1,
    nombre: 'Computadora de escritorio',
    categoria: 'Cómputo',
    cantidad: 18,
    estado: 'Disponible',
    icono: '💻',
    descripcion: 'Equipo para prácticas de programación y ofimática.'
  },
  {
    id: 2,
    nombre: 'Proyector multimedia',
    categoria: 'Audiovisual',
    cantidad: 3,
    estado: 'Disponible',
    icono: '📽️',
    descripcion: 'Proyección de presentaciones y material de clase.'
  },
  {
    id: 3,
    nombre: 'Impresora multifuncional',
    categoria: 'Impresión',
    cantidad: 2,
    estado: 'Mantenimiento',
    icono: '🖨️',
    descripcion: 'Impresión y digitalización de documentos.'
  },
  {
    id: 4,
    nombre: 'Router inalámbrico',
    categoria: 'Redes',
    cantidad: 5,
    estado: 'Disponible',
    icono: '📡',
    descripcion: 'Conectividad para las prácticas de redes.'
  },
  {
    id: 5,
    nombre: 'Switch de red',
    categoria: 'Redes',
    cantidad: 4,
    estado: 'Uso limitado',
    icono: '🔌',
    descripcion: 'Dispositivo para ejercicios de conexión LAN.'
  },
  {
    id: 6,
    nombre: 'Regulador de voltaje',
    categoria: 'Energía',
    cantidad: 12,
    estado: 'Disponible',
    icono: '🔋',
    descripcion: 'Protección eléctrica para los equipos del laboratorio.'
  }
];

function App() {
  const [inventarioVisible, setInventarioVisible] = useState(true);
  const totalUnidades = equipos.reduce((total, equipo) => total + equipo.cantidad, 0);
  const disponibles = equipos.filter((equipo) => equipo.estado === 'Disponible').length;

  return (
    <div className="app-shell">
      <header className="hero-section">
        <nav className="navbar navbar-dark">
          <div className="container">
            <a className="navbar-brand d-flex align-items-center gap-2" href="#inicio">
              <span className="brand-mark">IL</span>
              <span>Laboratorio <strong>UNAN–LEÓN</strong></span>
            </a>
            <span className="nav-label">Gestión de equipos</span>
          </div>
        </nav>

        <div className="container hero-content" id="inicio">
          <div className="hero-copy">
            <span className="eyebrow">CONTROL DE ACTIVOS</span>
            <h1>Inventario de equipos<br /><span>del laboratorio</span></h1>
            <p>Consulta de forma rápida los recursos tecnológicos disponibles para las prácticas académicas.</p>
            <table className="participant-table">
              <thead>
                <tr>
                  <th scope="col">Nombre</th>
                  <th scope="col">Nº Único</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>Robert José Ortega</td><td>6A163911</td></tr>
                <tr><td>Yasser Steven Hernández chavarria</td><td>706E8224</td></tr>
                <tr><td>Vladimir Eduardo Varela Machado</td><td>6FC4B806</td></tr>
                <tr><td>Victoriano Ramon Antón</td><td>63B4AFF9</td></tr>
              </tbody>
            </table>
            <button
              type="button"
              className={`btn ${inventarioVisible ? 'btn-light' : 'btn-warning'} hero-button`}
              onClick={() => setInventarioVisible((visible) => !visible)}
              aria-expanded={inventarioVisible}
              aria-controls="lista-inventario"
            >
              <span aria-hidden="true">{inventarioVisible ? '▤' : '＋'}</span>
              {inventarioVisible ? 'Ocultar inventario' : 'Mostrar inventario'}
            </button>
          </div>
          <div className="hero-illustration" aria-hidden="true">
            <div className="orbit orbit-one"></div>
            <div className="orbit orbit-two"></div>
            <div className="device-card"><span>⌘</span><i></i><i></i><i></i></div>
            <div className="floating-dot dot-one"></div>
            <div className="floating-dot dot-two"></div>
          </div>
        </div>
      </header>

      <main className="container main-content">
        <section className="summary-grid" aria-label="Resumen del inventario">
          <div className="summary-card">
            <span className="summary-icon icon-blue">▦</span>
            <div><p>Tipos de equipo</p><strong>{equipos.length}</strong></div>
          </div>
          <div className="summary-card">
            <span className="summary-icon icon-green">✓</span>
            <div><p>Tipos disponibles</p><strong>{disponibles}</strong></div>
          </div>
          <div className="summary-card">
            <span className="summary-icon icon-violet">▤</span>
            <div><p>Unidades registradas</p><strong>{totalUnidades}</strong></div>
          </div>
        </section>

        <section className="inventory-section" id="lista-inventario">
          <div className="section-heading">
            <div>
              <span className="eyebrow dark-eyebrow">REGISTRO ACTUAL</span>
              <h2>Equipos registrados</h2>
              <p>Listado de recursos del laboratorio y su estado actual.</p>
            </div>
            {inventarioVisible && <span className="record-count">{equipos.length} registros</span>}
          </div>

          {inventarioVisible ? (
            <div className="row g-4">
              {equipos.map((equipo) => (
                <div className="col-12 col-sm-6 col-lg-4" key={equipo.id}>
                  <TarjetaEquipo equipo={equipo} />
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <span className="empty-icon">▤</span>
              <h3>Inventario oculto</h3>
              <p>Presiona “Mostrar inventario” para volver a consultar los equipos registrados.</p>
            </div>
          )}
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-inner">
          <span>UNAN–LEÓN · Desarrollo de Entornos Web II</span>
          <span>Proyecto práctico · React + Bootstrap 5</span>
        </div>
      </footer>
    </div>
  );
}

export default App;